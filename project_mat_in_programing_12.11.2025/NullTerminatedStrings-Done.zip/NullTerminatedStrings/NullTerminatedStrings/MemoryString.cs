﻿using System;
using System.Text;

namespace NullTerminatedStrings
{
    public unsafe class MemoryString
    {
        public char* StringToCharPointer(string str)
        {
            string nullTerminatedStr = str + '\0';

            fixed (char* ptr = nullTerminatedStr)
            {
                char* result = (char*)System.Runtime.InteropServices.Marshal.AllocHGlobal(
                    (nullTerminatedStr.Length + 1) * sizeof(char));

                for (int i = 0; i < nullTerminatedStr.Length; i++)
                {
                    result[i] = nullTerminatedStr[i];
                }

                return result;
            }
        }

        public int strlen(char* str)
        {
            int len = 0;

            while (*(str + len) != '\0')
            {
                len++;
            }

            return len;
        }

        public void strcpy(char* dest, char* src)
        {
            int i = 0;

            while (*(src + i) != '\0')
            {
                *(dest + i) = *(src + i);
                i++;
            }

            *(dest + i) = '\0';
        }

        public string strprint(char* str)
        {
            StringBuilder sb = new StringBuilder();
            int i = 0;
            
            while (*(str + i) != '\0')
            {
                sb.Append(*(str + i));
                i++;
            }

            return sb.ToString();
        }

        public char* strchr(char* str, char chr)
        {
            int i = 0;

            while (*(str + i) != '\0')
            {
                if (*(str + i) == chr)
                {
                    return str + i;
                }
                i++;
            }

            return null;
        }

        public int strcmp(char* strOne, char* strTwo)
        {
            int i = 0;

            while (*(strOne + i) != '\0' && *(strTwo + i) != '\0')
            {
                if (*(strOne + i) < *(strTwo + i))
                {
                    return -1;
                }
                else if (*(strOne + i) > *(strTwo + i))
                {
                    return 1;
                }
                i++;
            }

            if (*(strOne + i) == '\0' && *(strTwo + i) != '\0')
            {
                return -1;
            }
            else if (*(strOne + i) != '\0' && *(strTwo + i) == '\0')
            {
                return 1;
            }

            return 0;
        }

        public char* strcat(char* dest, char* src)
        {
            int destLen = strlen(dest);
            int srcLen = strlen(src);
            int totalLen = destLen + srcLen;

            char* result = strptrsize(totalLen + 1);

            strcpy(result, dest);

            int resultPtrOffset = 0;
            while (*(result + resultPtrOffset) != '\0')
            {
                resultPtrOffset++;
            }

            int srcPtrOffset = 0;
            while (*(src + srcPtrOffset) != '\0')
            {
                *(result + resultPtrOffset + srcPtrOffset) = *(src + srcPtrOffset);
                srcPtrOffset++;
            }

            *(result + resultPtrOffset + srcPtrOffset) = '\0';

            return result;
        }

        private char* strptrsize(int size)
        {

            char* ptr = (char*)System.Runtime.InteropServices.Marshal.AllocHGlobal(size * sizeof(char));
            return ptr;
        }
    }
}