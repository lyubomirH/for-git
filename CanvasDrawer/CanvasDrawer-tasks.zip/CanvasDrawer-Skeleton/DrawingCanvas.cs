﻿namespace CanvasDrawer
{
    public class DrawingCanvas : ICloneable
    {
        private uint[][] pixels;

        public DrawingCanvas(int width, int height)
        {
            if (width < 32 || width > 1024 || width % 32 != 0)
            {
                throw new ArgumentException("Invalid width! Width should be in range [32 ... 1024] and should be divisible by 32.");
            }

            if (height < 32 || height > 1024)
            {
                throw new ArgumentException("Invalid height! Height should be in range [32 ... 1024].");
            }

            // Allocate the pixels in the image
            int widthInts = width / 32;
            this.pixels = new uint[height][];
            for (int row = 0; row < height; row++)
            {
                this.pixels[row] = new uint[widthInts];
            }

            // Initialize with white pixels
            this.FillAllPixels(CanvasColor.White);
        }

        public int Width => this.pixels[0].Length * 32;

        public int Height => this.pixels.Length;

        public int RowCount => this.pixels.Length;

        public int ColCount => this.pixels[0].Length;

        public void FillAllPixels(CanvasColor color)
        {
            uint mask = color == CanvasColor.Black ? 0u : ~0u;

            for (int row = 0; row < this.RowCount; row++)
            {
                for (int col = 0; col < this.ColCount; col++)
                {
                    this.pixels[row][col] = mask;
                }
            }
        }

        public void InvertAllPixels()
        {
            for (int row = 0; row < this.RowCount; row++)
            {
                for (int col = 0; col < this.ColCount; col++)
                {
                    this.pixels[row][col] = ~this.pixels[row][col];
                }
            }
        }

        public CanvasColor GetPixel(int row, int col)
        {
            this.CheckBounds(row, col);

            int targetCol = col / 32;
            int bitIndex = col % 32;

            uint targetInt = this.pixels[row][targetCol];
            uint bit = (targetInt >> bitIndex) & 1;

            return (CanvasColor)bit;
        }

        public void SetPixel(int row, int col, CanvasColor color)
        {
            this.CheckBounds(row, col);

            int targetCol = col / 32;
            int bitIndex = col % 32;

            // Clear the bit first
            uint mask = ~(1u << bitIndex);
            uint clearedInt = this.pixels[row][targetCol] & mask;

            // Set the bit if color is White (1)
            if (color == CanvasColor.White)
            {
                uint setMask = 1u << bitIndex;
                clearedInt |= setMask;
            }

            this.pixels[row][targetCol] = clearedInt;
        }

        public void DrawHorizontalLine(int row, int startCol, int endCol, CanvasColor color)
        {
            this.CheckBounds(row, startCol);
            this.CheckBounds(row, endCol);

            if (startCol > endCol)
            {
                // Swap if start is greater than end
                int temp = startCol;
                startCol = endCol;
                endCol = temp;
            }

            for (int col = startCol; col <= endCol; col++)
            {
                this.SetPixel(row, col, color);
            }
        }

        public void DrawVerticalLine(int col, int startRow, int endRow, CanvasColor color)
        {
            this.CheckBounds(startRow, col);
            this.CheckBounds(endRow, col);

            if (startRow > endRow)
            {
                // Swap if start is greater than end
                int temp = startRow;
                startRow = endRow;
                endRow = temp;
            }

            for (int row = startRow; row <= endRow; row++)
            {
                this.SetPixel(row, col, color);
            }
        }

        public void DrawRectangle(int startRow, int startCol, int endRow, int endCol, CanvasColor color)
        {
            this.CheckBounds(startRow, startCol);
            this.CheckBounds(endRow, endCol);

            if (startRow > endRow)
            {
                int temp = startRow;
                startRow = endRow;
                endRow = temp;
            }

            if (startCol > endCol)
            {
                int temp = startCol;
                startCol = endCol;
                endCol = temp;
            }

            // Draw top and bottom horizontal lines
            this.DrawHorizontalLine(startRow, startCol, endCol, color);
            this.DrawHorizontalLine(endRow, startCol, endCol, color);

            // Draw left and right vertical lines
            this.DrawVerticalLine(startCol, startRow, endRow, color);
            this.DrawVerticalLine(endCol, startRow, endRow, color);
        }

        private void CheckBounds(int row, int col)
        {
            int maxWidth = this.Width - 1;
            if (col < 0 || col > maxWidth)
            {
                throw new ArgumentException($"Invalid column! Column should be in range [0 ... {maxWidth}].");
            }

            int maxHeight = this.Height - 1;
            if (row < 0 || row > maxHeight)
            {
                throw new ArgumentException($"Invalid row! Row should be in range [0 ... {maxHeight}].");
            }
        }

        public object Clone()
        {
            DrawingCanvas clone = new DrawingCanvas(this.Width, this.Height);

            for (int row = 0; row < this.RowCount; row++)
            {
                Array.Copy(this.pixels[row], clone.pixels[row], this.pixels[row].Length);
            }

            return clone;
        }
    }
}