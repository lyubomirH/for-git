﻿namespace ColoredCanvasDrawer
{
    public class DrawingCanvas : ICloneable
    {
        private byte[][] pixels;

        public DrawingCanvas(int width, int height)
        {
            if (width < 32 || width > 1024)
            {
                throw new ArgumentException("Invalid width! Width should be in range [32 ... 1024].");
            }

            if (height < 32 || height > 1024)
            {
                throw new ArgumentException("Invalid height! Height should be in range [32 ... 1024].");
            }

            int widthColor = width * 3;
            this.pixels = new byte[height][];
            for (int row = 0; row < height; row++)
            {
                this.pixels[row] = new byte[widthColor];
            }

            this.FillAllPixels();
        }

        public int Height => this.pixels.Length;

        public int Width => this.pixels[0].Length;

        public void FillAllPixels()
        {
            byte mask = 0;
            mask = (byte)~mask;

            for (int row = 0; row < this.Height; row++)
            {
                for (int col = 0; col < this.Width; col++)
                {
                    this.pixels[row][col] = mask;
                }
            }
        }

        public void InvertAllPixels()
        {
            for (int row = 0; row < this.Height; row++)
            {
                for (int col = 0; col < this.Width; col++)
                {
                    this.pixels[row][col] = (byte)~this.pixels[row][col];
                }
            }
        }

        public Color GetPixel(int row, int col)
        {
            this.CheckBounds(row, col);

            int pixelOffset = col * 3;

            byte red = this.pixels[row][pixelOffset];
            byte green = this.pixels[row][pixelOffset + 1];
            byte blue = this.pixels[row][pixelOffset + 2];

            return Color.FromArgb(red, green, blue);
        }

        public void SetPixel(int row, int col, Color color)
        {
            this.CheckBounds(row, col);

            int pixelOffset = col * 3;

            this.pixels[row][pixelOffset] = color.R;
            this.pixels[row][pixelOffset + 1] = color.G;
            this.pixels[row][pixelOffset + 2] = color.B;
        }

        public void DrawHorizontalLine(int row, int startCol, int endCol, Color color)
        {
            // Ensure startCol is less than endCol
            if (startCol > endCol)
            {
                int temp = startCol;
                startCol = endCol;
                endCol = temp;
            }

            for (int col = startCol; col <= endCol; col++)
            {
                this.SetPixel(row, col, color);
            }
        }

        public void DrawVerticalLine(int col, int startRow, int endRow, Color color)
        {
            // Ensure startRow is less than endRow
            if (startRow > endRow)
            {
                int temp = startRow;
                startRow = endRow;
                endRow = temp;
            }

            for (int row = startRow; row <= endRow; row++)
            {
                this.SetPixel(row, col, color);
            }
        }

        public void DrawDiagonalLine(int startRow, int startCol, int endRow, int endCol, Color color)
        {
            this.PlotLine(startCol, startRow, endCol, endRow, color);
        }

        public void DrawRectangle(int startRow, int startCol, int endRow, int endCol, Color color)
        {
            // Ensure proper ordering of coordinates
            int top = Math.Min(startRow, endRow);
            int bottom = Math.Max(startRow, endRow);
            int left = Math.Min(startCol, endCol);
            int right = Math.Max(startCol, endCol);

            this.DrawHorizontalLine(top, left, right, color);
            this.DrawHorizontalLine(bottom, left, right, color);
            this.DrawVerticalLine(left, top, bottom, color);
            this.DrawVerticalLine(right, top, bottom, color);
        }

        public void DrawTriangle(int startRow, int startCol, int endRow, int endCol, Color color)
        {
            // Draw a triangle with three points:
            // Point A: (startRow, startCol) - top vertex
            // Point B: (endRow, startCol) - bottom left vertex  
            // Point C: (startRow, endCol) - bottom right vertex

            int midRow = endRow; // Bottom row
            int leftCol = startCol; // Left column
            int rightCol = endCol; // Right column
            int topRow = startRow; // Top row

            // Draw three sides of the triangle
            this.DrawDiagonalLine(topRow, leftCol, midRow, rightCol, color); // Hypotenuse (left to right)
            this.DrawVerticalLine(leftCol, topRow, midRow, color);           // Left side
            this.DrawHorizontalLine(midRow, leftCol, rightCol, color);       // Bottom side
        }

        private void PlotLine(int x0, int y0, int x1, int y1, Color color)
        {
            if (Math.Abs(y1 - y0) < Math.Abs(x1 - x0))
            {
                if (x0 > x1)
                {
                    this.PlotLineLow(x1, y1, x0, y0, color);
                }
                else
                {
                    this.PlotLineLow(x0, y0, x1, y1, color);
                }
            }
            else
            {
                if (y0 > y1)
                {
                    this.PlotLineHigh(x1, y1, x0, y0, color);
                }
                else
                {
                    this.PlotLineHigh(x0, y0, x1, y1, color);
                }
            }
        }

        private void PlotLineLow(int x0, int y0, int x1, int y1, Color color)
        {
            int dx = x1 - x0;
            int dy = y1 - y0;
            int yi = 1;

            if (dy < 0)
            {
                yi = -1;
                dy = -dy;
            }

            int D = (2 * dy) - dx;
            int y = y0;

            for (int x = x0; x <= x1; x++)
            {
                this.SetPixel(y, x, color);

                if (D > 0)
                {
                    y = y + yi;
                    D = D + (2 * (dy - dx));
                }
                else
                {
                    D = D + 2 * dy;
                }
            }
        }

        private void PlotLineHigh(int x0, int y0, int x1, int y1, Color color)
        {
            int dx = x1 - x0;
            int dy = y1 - y0;
            int xi = 1;

            if (dx < 0)
            {
                xi = -1;
                dx = -dx;
            }

            int D = (2 * dx) - dy;
            int x = x0;

            for (int y = y0; y <= y1; y++)
            {
                this.SetPixel(y, x, color);

                if (D > 0)
                {
                    x = x + xi;
                    D = D + (2 * (dx - dy));
                }
                else
                {
                    D = D + 2 * dx;
                }
            }
        }

        private void CheckBounds(int row, int col)
        {
            int maxCol = this.Width / 3 - 1;
            if (col < 0 || col > maxCol)
            {
                throw new ArgumentException($"Invalid column! Column should be in range [0 ... {maxCol}].");
            }

            int maxRow = this.Height - 1;
            if (row < 0 || row > maxRow)
            {
                throw new ArgumentException($"Invalid row! Row should be in range [0 ... {maxRow}].");
            }
        }

        public object Clone()
        {
            DrawingCanvas clone = new DrawingCanvas(this.Width / 3, this.Height);

            for (int row = 0; row < this.Height; row++)
            {
                Array.Copy(this.pixels[row], clone.pixels[row], this.pixels[row].Length);
            }

            return clone;
        }
    }
}